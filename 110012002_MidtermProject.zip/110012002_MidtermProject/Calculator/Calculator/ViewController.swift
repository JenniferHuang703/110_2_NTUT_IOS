//
//  ViewController.swift
//  Calculator
//
//  Created by Jennifer Huang on 2022-03-21.
//

import UIKit

extension Double {
    var clean: String {
       return self.truncatingRemainder(dividingBy: 1) == 0 ? String(format: "%.0f", self) : String(self)
    }
}

enum Operation:String{
    case Add = "+"
    case Substract = "-"
    case Multiply = "*"
    case Division = "/"
    case PosNeg = "+/-"
    case NULL = "NULL"
}

class ViewController: UIViewController {

    @IBOutlet weak var topLabel: UILabel!
    

    @IBOutlet weak var allClearLabel: UIButton!
    @IBOutlet weak var DivisionButton: UIButton!
    @IBOutlet weak var MultiplicationButton: UIButton!
    @IBOutlet weak var SubstractionButton: UIButton!
    @IBOutlet weak var AdditionButton: UIButton!
    
    var result = 0.0
    var leftValue = 0.0
    var rightValue = 0.0
    var currentValue = ""
    var currentOperation: Operation?
    var equalIsPressed = false
    var operatorIsClicked = false
    var positiveBtnIsClicked = false
    var hasValueClicked = false
    
    @IBOutlet weak var displayResult: UILabel!
    
    @IBAction func handleOperations(_ sender: UIButton) {
        let tag = sender.tag
        
        if(currentValue != ""){
            trimZeros()
        }
        
        if tag == 0 {
            equalIsPressed = true
            topLabel.text = topLabel.text! + "="
            if let operation = currentOperation {
                switch operation {
                case .Add:
                    operationPressed(operation: .Add)
                    break

                case .Substract:
                    operationPressed(operation: .Substract)
                    break

                case .Multiply:
                    operationPressed(operation: .Multiply)
                    break

                case .Division:
                    operationPressed(operation: .Division)
                    break
                case .PosNeg:
                    operationPressed(operation: .PosNeg)
                case .NULL:
                    operationPressed(operation: .NULL)
                    break
                }
            }
        }
        else if tag == 1 {
            handleOperationCLicked(sender, .Add)
        }
        else if tag == 2 {
            handleOperationCLicked(sender, .Substract)
        }
        else if tag == 3 {
            handleOperationCLicked(sender, .Multiply)
        }
        else if tag == 4 {
            handleOperationCLicked(sender, .Division)
        }
        else if tag == 5 {
            handlePosNegPressed()
        }
    }
    
    func handleOperationCLicked(_ sender: UIButton,_ operationClicked: Operation) {
        operatorIsClicked = true
        unhighlightPreviousOperation(isHighlighted: true)
        highlightSelectedOperator(sender)
        operationPressed(operation: operationClicked)
        currentOperation = operationClicked
        if (hasValueClicked) {
            topLabel.text = topLabel.text! + operationClicked.rawValue
        }
        hasValueClicked = true
    }
    
    func handlePosNegPressed() {
        var value = currentValue == "" ? 0 : Double(currentValue)!
        if value != 0 {
            value.negate()
        }
        let valueInString = NSNumber(value: value).stringValue
        let smth = topLabel.text
        let s = smth?.dropLast(currentValue.count)
        currentValue = valueInString
        displayResult.text = "\(valueInString)"
        
        if(currentOperation != nil) {
            topLabel.text = s! + valueInString
        } else {
            topLabel.text = valueInString
        }
    }
    
    func trimZeros() {
        let string = topLabel.text
        let trimmedString = string?.dropLast(currentValue.count)
        let currentVal = currentValue == "" ? 0.0 : Double(currentValue)!

        let cleanVal = currentVal.clean
        var trimmedLeadingZeros = cleanVal
        if (cleanVal != "0"){
            trimmedLeadingZeros =  cleanVal.replacingOccurrences(of: "^0+", with: "", options: .regularExpression)
        }
        topLabel.text = trimmedString! + trimmedLeadingZeros
    }
    
    func unhighlightPreviousOperation(isHighlighted: Bool) {
        if let operation = currentOperation {
            switch operation {
            case .Add:
                isHighlighted ? unhighlightButton(AdditionButton) : highlightSelectedOperator(AdditionButton)
                break

            case .Substract:
                isHighlighted ? unhighlightButton(SubstractionButton) : highlightSelectedOperator(SubstractionButton)
                break

            case .Multiply:
                isHighlighted ? unhighlightButton(MultiplicationButton) : highlightSelectedOperator(MultiplicationButton)
                break

            case .Division:
                isHighlighted ? unhighlightButton(DivisionButton) : highlightSelectedOperator(DivisionButton)
                break
            case .PosNeg:
                break
            case .NULL:
                break
            }
        }
    }
    
    func highlightSelectedOperator(_ sender: UIButton) {
        sender.backgroundColor = sender.backgroundColor == #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1) ? UIColor.white : #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        sender.setTitleColor(sender.titleColor(for: .normal) == UIColor.white ? #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1): UIColor.white, for: .normal)
    }
    
    func unhighlightButton(_ sender: UIButton) {
        sender.backgroundColor = #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        sender.setTitleColor(UIColor.white, for: .normal)
    }
    
    func unhighlightAll() {
        AdditionButton.backgroundColor = #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        AdditionButton.setTitleColor(UIColor.white, for: .normal)
        SubstractionButton.backgroundColor = #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        SubstractionButton.setTitleColor(UIColor.white, for: .normal)
        MultiplicationButton.backgroundColor = #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        MultiplicationButton.setTitleColor(UIColor.white, for: .normal)
        DivisionButton.backgroundColor = #colorLiteral(red: 0.9788091779, green: 0.9195151329, blue: 0.7855257392, alpha: 1)
        DivisionButton.setTitleColor(UIColor.white, for: .normal)
    }
    
    func operationPressed(operation: Operation){
        if currentOperation != nil {
            if currentValue != "" {
                rightValue = Double(currentValue)!
                currentValue = ""

                if currentOperation == .Add {
                    result = (leftValue) + (rightValue)
                }else  if currentOperation == .Substract {
                    result = (leftValue) - (rightValue)
                }else  if currentOperation == .Multiply {
                    result = (leftValue) * (rightValue)
                }else  if currentOperation == .Division {
                    result = (leftValue) / (rightValue)
                    if(rightValue == 0){
                        result = 0
                    }
                }else if currentOperation == .PosNeg {
                    rightValue.negate()
                }
                leftValue = result
                let valueInString = NSNumber(value: result).stringValue
                displayResult.lineBreakMode = .byClipping
                displayResult.text = "\(valueInString)"
            }
            currentOperation = operation
        } else {
            if(currentValue == "") {
                leftValue = 0
                topLabel.text = "0"
            } else {
                leftValue = Double(currentValue)!
            }
            currentValue = ""
            currentOperation = operation
        }
    }
    
    func clearValue() {
        if(equalIsPressed || currentOperation == nil || allClearLabel.title(for: .normal) == "AC") {
            result = 0
            leftValue = 0
            rightValue = 0
            currentValue = ""
            currentOperation = nil
            displayResult.text = "0"
            topLabel.text = ""
            equalIsPressed = false
            unhighlightAll()
        } else {
            unhighlightPreviousOperation(isHighlighted: false)
            
            let smth = topLabel.text
            let s = smth?.dropLast(currentValue.count)
            topLabel.text = s! + ""
           
            rightValue = 0
            displayResult.text = "0"
            currentValue = ""
        }
        allClearLabel.setTitle("AC", for: .normal)
        hasValueClicked = false
    }

    @IBAction func numberPressed(_ sender: UIButton) {
        allClearLabel.setTitle("C", for: .normal)
        if(equalIsPressed) {
            clearValue()
            setValue(sender)
        }else {
            unhighlightPreviousOperation(isHighlighted : true)
            setValue(sender)
        }
        hasValueClicked = true
    }
    
    func setValue(_ sender: UIButton) {
        operatorIsClicked = false
//        if(!(sender.tag == 0 && (currentValue == "" || currentValue == "0"))) {
            currentValue += "\(sender.tag)"
            displayResult.text = currentValue
            topLabel.text = topLabel.text! + "\(sender.tag)"
//        }
    }
    
    @IBAction func allClear(_ sender: UIButton) {
        if(!operatorIsClicked) {
            clearValue()
        }
    }
    
    @IBAction func dotPressed(_ sender: Any) {
        if (displayResult.text?.range(of: ".") == nil) {
            currentValue += "."
            displayResult.text = "\(currentValue)"
            topLabel.text = topLabel.text! + "."
        }
    }
    
    @IBAction func percentagePressed(_ sender: UIButton) {
        let value = Double(currentValue) == nil ? (result/100) : (Double(currentValue)!/100)
        currentValue = "\(value)"
        topLabel.text = currentValue
        displayResult.text = "\(value)"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

